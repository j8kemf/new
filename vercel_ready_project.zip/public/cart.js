// cart.js
const cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(product) {
    cart.push(product);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartDropdown = document.querySelector(".dropdown-cart");
    cartDropdown.innerHTML = "";
    cart.forEach((item, index) => {
        const cartItem = document.createElement("p");
        cartItem.innerText = `${item.name} - $${item.price}`;
        cartDropdown.appendChild(cartItem);
    });
}

// Call updateCartDisplay on page load to reflect saved cart items
document.addEventListener("DOMContentLoaded", updateCartDisplay);
